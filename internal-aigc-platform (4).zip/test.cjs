const http = require('http');

const data = JSON.stringify({ timer: 2 });

const options = {
  hostname: 'localhost',
  port: 3000,
  path: '/api/timer/reset',
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
    'x-admin-password': '18190000',
    'Content-Length': data.length
  }
};

const req = http.request(options, (res) => {
  let resData = '';
  res.on('data', (chunk) => {
    resData += chunk;
  });
  res.on('end', () => {
    console.log('Response:', resData);
  });
});

req.on('error', (error) => {
  console.error(error);
});

req.write(data);
req.end();
