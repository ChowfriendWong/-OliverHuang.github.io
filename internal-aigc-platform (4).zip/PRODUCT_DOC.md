# Internal AIGC Platform - Product Documentation

**Developed by:** Oliver Huang

## 1. Product Overview
The Internal AIGC Platform is a comprehensive, web-based AI generation tool designed to streamline the creative workflow for designers, artists, and content creators. It integrates advanced AI models (such as Gemini 3.1 Flash/Pro Image Preview and Gemini 2.5 Flash) to offer powerful image generation, local image editing, and 3D model viewing capabilities in a single, cohesive interface.

## 2. Key Features

### 2.1 Image Generation
*   **Single Image Generation:** Generate high-quality images from text prompts.
*   **Storyboard Generation:** Automatically generate a cohesive 9-frame cinematic storyboard sequence based on a single scene description, maintaining consistent style and character appearance.
*   **Model Selection:** Choose between different AI models (e.g., Banana Pro, Banana 2) to suit different quality and speed requirements.
*   **Aspect Ratio Control:** Select from standard aspect ratios including 1:1 (Square), 16:9 (Landscape), 9:16 (Portrait), 4:3, and 3:4.

### 2.2 Advanced Prompting & Styling
*   **Style Presets:** Apply predefined style templates (e.g., Cinematic, Anime, 3D Render, Cyberpunk) to easily achieve specific artistic looks without writing complex prompts from scratch.
*   **Autopilot (Image Analysis):** Upload an existing image and let the AI analyze its style, lighting, and composition to automatically generate a detailed prompt that replicates the look.
*   **Image References:** Upload multiple reference images and assign specific attributes (e.g., "Character", "Background") and influence levels (Low, High) to guide the generation process.

### 2.3 Image Editing (Local Edit)
*   **Brush Masking:** Draw directly on generated images using a built-in brush tool to highlight specific regions.
*   **Targeted Modification:** Provide a text prompt to modify *only* the highlighted area, leaving the rest of the image untouched.

### 2.4 3DGS Viewer Integration
*   **3D Gaussian Splatting:** Upload and view `.splat` files directly in the browser.
*   **Interactive Controls:** Pan, zoom, and rotate the 3D model. A dedicated "Model Transform" panel allows precise X, Y, and Z axis rotation adjustments.
*   **Capture Reference:** Capture the current view of the 3D model and instantly use it as an image reference for 2D generation.

### 2.5 Admin Dashboard
*   **Access Control:** Secure admin login (double-click the app icon in the header).
*   **Preset Management:** Create, edit, and delete custom style presets.
*   **Usage Logs:** View a history of generated images, prompts, and timestamps.
*   **API Configuration:** Manage API keys (Gemini API) directly from the UI.
*   **Quota Management:** Set and reset the generation quota (timer) for users.

## 3. User Interface Layout
*   **Header:** Displays the platform title, developer credit, and remaining generation quota.
*   **Left Panel (Controls):** Contains model selection, generation mode (Single/Storyboard), style presets, aspect ratio, prompt input, and the "Generate" button.
*   **Right Panel (Workspace):** Displays the generated image, local edit controls, image reference uploads, and the 3DGS Viewer toggle.

## 4. Technical Stack
*   **Frontend:** React, TypeScript, Tailwind CSS, Vite.
*   **AI Integration:** Google GenAI SDK (`@google/genai`).
*   **3D Rendering:** `@antimatter15/splat` for 3D Gaussian Splatting rendering.
*   **Icons:** Lucide React.

## 5. Usage Workflow Example
1.  **Setup:** Select the desired AI model and generation mode (e.g., Single Image).
2.  **Style:** Choose a Style Preset or use Autopilot to extract a style from a reference image.
3.  **Dimensions:** Select the desired Aspect Ratio (e.g., 16:9).
4.  **References (Optional):** Upload a 3D model, adjust its rotation, capture a reference, or upload 2D reference images.
5.  **Prompt:** Enter the description of the desired image.
6.  **Generate:** Click "Generate Image".
7.  **Refine:** Use the "Local Edit" brush tool to make specific adjustments to the generated image.
8.  **Export:** Download the final image.
