import React, { useState, useEffect, useRef } from 'react';
import { GoogleGenAI } from '@google/genai';
import { Settings, Image as ImageIcon, Key, LogOut, Trash2, Plus, Loader2, Upload, Brush, X, Box } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { cn } from './utils';
import GsplatViewer from './components/GsplatViewer';

declare global {
  interface Window {
    aistudio?: {
      hasSelectedApiKey: () => Promise<boolean>;
      openSelectKey: () => Promise<void>;
    };
  }
}

type Preset = {
  id: number;
  name: string;
  prompt_template: string;
};

type ImageReference = {
  id: string;
  file: string;
  attributeName: string;
  influence: 'Low' | 'High';
};

type Log = {
  id: number;
  timestamp: string;
  prompt: string;
  model: string;
  status: string;
  error: string | null;
  image_data: string | null;
  attributes: string | null;
};

function useWindowScale(baseWidth = 1920, baseHeight = 1080) {
  const [scale, setScale] = useState(1);

  useEffect(() => {
    const handleResize = () => {
      const width = window.innerWidth;
      const height = window.innerHeight;
      const scaleX = width / baseWidth;
      const scaleY = height / baseHeight;
      setScale(Math.min(scaleX, scaleY));
    };

    handleResize();
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, [baseWidth, baseHeight]);

  return scale;
}

export default function App() {
  const scale = useWindowScale();
  const [showSplash, setShowSplash] = useState(true);
  const [isAdmin, setIsAdmin] = useState(false);
  const [showAdminLogin, setShowAdminLogin] = useState(false);
  const [adminPassword, setAdminPassword] = useState('');
  
  const [hasKey, setHasKey] = useState(false);
  const [timer, setTimer] = useState<number | null>(null);
  const [carouselImages, setCarouselImages] = useState<string[]>([]);
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  
  const [presets, setPresets] = useState<Preset[]>([]);
  const [selectedModel, setSelectedModel] = useState('gemini-3-pro-image-preview');
  const [outcome, setOutcome] = useState<'single' | 'storyboard'>('single');
  const [selectedPresetId, setSelectedPresetId] = useState<number | '' | 'autopilot'>('');
  const [aspectRatio, setAspectRatio] = useState('1:1');
  const [imageSize, setImageSize] = useState('1K');
  const [prompt, setPrompt] = useState('');
  const [loading, setLoading] = useState(false);
  const [autopilotLoading, setAutopilotLoading] = useState(false);
  const [autopilotImage, setAutopilotImage] = useState<string | null>(null);
  const [imageReferences, setImageReferences] = useState<ImageReference[]>([]);
  const [imageUrl, setImageUrl] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  // 3DGS Viewer State
  const [showGsplatViewer, setShowGsplatViewer] = useState(false);

  // Region Editing State
  const [isEditingRegion, setIsEditingRegion] = useState(false);
  const [editPrompt, setEditPrompt] = useState('');
  const [isDrawing, setIsDrawing] = useState(false);
  const [editLoading, setEditLoading] = useState(false);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const imageRef = useRef<HTMLImageElement>(null);

  // Admin state
  const [logs, setLogs] = useState<Log[]>([]);
  const [adminTab, setAdminTab] = useState<'presets' | 'logs' | 'settings'>('presets');
  const [newPresetName, setNewPresetName] = useState('');
  const [newPresetTemplate, setNewPresetTemplate] = useState('');
  const [storyboardPromptTemplate, setStoryboardPromptTemplate] = useState('');
  const [adminStoryboardPrompt, setAdminStoryboardPrompt] = useState('');
  const [adminCarouselImages, setAdminCarouselImages] = useState<string[]>([]);
  const [adminTimerValue, setAdminTimerValue] = useState<number>(100);

  const colorThemes = [
    { bg: 'from-orange-600 to-red-600', hover: 'hover:from-orange-500 hover:to-red-500', text: 'text-orange-400', border: 'border-orange-500/50', ring: 'focus:ring-orange-500 focus:border-orange-500' },
    { bg: 'from-blue-600 to-cyan-600', hover: 'hover:from-blue-500 hover:to-cyan-500', text: 'text-blue-400', border: 'border-blue-500/50', ring: 'focus:ring-blue-500 focus:border-blue-500' },
    { bg: 'from-emerald-600 to-teal-600', hover: 'hover:from-emerald-500 hover:to-teal-500', text: 'text-emerald-400', border: 'border-emerald-500/50', ring: 'focus:ring-emerald-500 focus:border-emerald-500' },
    { bg: 'from-purple-600 to-pink-600', hover: 'hover:from-purple-500 hover:to-pink-500', text: 'text-purple-400', border: 'border-purple-500/50', ring: 'focus:ring-purple-500 focus:border-purple-500' },
  ];
  const currentTheme = colorThemes[currentImageIndex % colorThemes.length] || colorThemes[0];

  useEffect(() => {
    const timer = setTimeout(() => {
      setShowSplash(false);
    }, 3500);
    return () => clearTimeout(timer);
  }, []);

  useEffect(() => {
    const checkKey = async () => {
      if (window.aistudio?.hasSelectedApiKey) {
        const selected = await window.aistudio.hasSelectedApiKey();
        setHasKey(selected);
      }
    };
    checkKey();
    fetchPresets();
    fetchTimer();
    fetchStoryboardPrompt();
    fetchCarouselImages();
  }, []);

  useEffect(() => {
    if (carouselImages.length === 0) return;
    const interval = setInterval(() => {
      setCurrentImageIndex((prev) => (prev + 1) % carouselImages.length);
    }, 5000);
    return () => clearInterval(interval);
  }, [carouselImages]);

  const fetchCarouselImages = async () => {
    try {
      const res = await fetch('/api/settings/carousel_images');
      if (res.ok) {
        const data = await res.json();
        setCarouselImages(data.images);
        setAdminCarouselImages(data.images);
      }
    } catch (e) {
      console.error('Failed to fetch carousel images', e);
    }
  };

  const fetchStoryboardPrompt = async () => {
    try {
      const res = await fetch('/api/settings/storyboard_prompt');
      if (res.ok) {
        const data = await res.json();
        setStoryboardPromptTemplate(data.prompt);
        setAdminStoryboardPrompt(data.prompt);
      }
    } catch (e) {
      console.error('Failed to fetch storyboard prompt', e);
    }
  };

  const fetchTimer = async () => {
    try {
      const res = await fetch('/api/timer');
      if (res.ok) {
        const data = await res.json();
        setTimer(data.timer);
      }
    } catch (e) {
      console.error('Failed to fetch timer', e);
    }
  };

  const fetchPresets = async () => {
    try {
      const res = await fetch('/api/presets');
      if (res.ok) {
        const data = await res.json();
        setPresets(data);
      }
    } catch (e) {
      console.error('Failed to fetch presets', e);
    }
  };

  const handleSelectKey = async () => {
    if (window.aistudio?.openSelectKey) {
      try {
        await window.aistudio.openSelectKey();
        setHasKey(true);
      } catch (e) {
        console.error(e);
      }
    }
  };

  useEffect(() => {
    if (isEditingRegion && canvasRef.current && imageRef.current) {
      const canvas = canvasRef.current;
      const img = imageRef.current;
      
      // Match canvas size to image display size
      canvas.width = img.clientWidth;
      canvas.height = img.clientHeight;
      
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.lineCap = 'round';
        ctx.lineJoin = 'round';
        ctx.strokeStyle = 'rgba(255, 68, 68, 0.6)'; // Semi-transparent red for visibility
        ctx.lineWidth = 30;
      }
    }
  }, [isEditingRegion]);

  const startDrawing = (e: React.MouseEvent<HTMLCanvasElement> | React.TouchEvent<HTMLCanvasElement>) => {
    e.preventDefault();
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const rect = canvas.getBoundingClientRect();
    let clientX, clientY;

    if ('touches' in e) {
      clientX = e.touches[0].clientX;
      clientY = e.touches[0].clientY;
    } else {
      clientX = e.clientX;
      clientY = e.clientY;
    }

    const x = clientX - rect.left;
    const y = clientY - rect.top;

    ctx.beginPath();
    ctx.moveTo(x, y);
    setIsDrawing(true);
  };

  const draw = (e: React.MouseEvent<HTMLCanvasElement> | React.TouchEvent<HTMLCanvasElement>) => {
    e.preventDefault();
    if (!isDrawing) return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const rect = canvas.getBoundingClientRect();
    let clientX, clientY;

    if ('touches' in e) {
      clientX = e.touches[0].clientX;
      clientY = e.touches[0].clientY;
    } else {
      clientX = e.clientX;
      clientY = e.clientY;
    }

    const x = clientX - rect.left;
    const y = clientY - rect.top;

    ctx.lineTo(x, y);
    ctx.stroke();
  };

  const stopDrawing = () => {
    setIsDrawing(false);
  };

  const clearCanvas = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    ctx.clearRect(0, 0, canvas.width, canvas.height);
  };

  const handleEditRegion = async () => {
    if (!editPrompt || !imageUrl || !canvasRef.current || timer === null || timer <= 0) return;
    
    setEditLoading(true);
    setError(null);

    try {
      // Get the mask from the canvas
      const maskDataUrl = canvasRef.current.toDataURL('image/png');
      const maskBase64 = maskDataUrl.split(',')[1];
      const originalBase64 = imageUrl.split(',')[1];
      const mimeType = imageUrl.split(';')[0].split(':')[1] || 'image/png';

      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || process.env.GEMINI_API_KEY });
      
      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash-image', // Use 2.5 flash for editing
        contents: {
          parts: [
            {
              inlineData: {
                data: originalBase64,
                mimeType: mimeType
              }
            },
            {
              inlineData: {
                data: maskBase64,
                mimeType: 'image/png'
              }
            },
            {
              text: `Edit the first image based on this request: "${editPrompt}". The second image is a mask where the red strokes indicate the exact region to be modified. Only modify the highlighted region.`
            }
          ]
        }
      });

      let newBase64Image = null;
      if (response.candidates?.[0]?.content?.parts) {
        for (const part of response.candidates[0].content.parts) {
          if (part.inlineData) {
            newBase64Image = `data:${part.inlineData.mimeType};base64,${part.inlineData.data}`;
            break;
          }
        }
      }

      if (newBase64Image) {
        setImageUrl(newBase64Image);
        setIsEditingRegion(false);
        setEditPrompt('');
        
        // Decrement timer
        const timerRes = await fetch('/api/timer/decrement', { method: 'POST' });
        if (timerRes.ok) {
          const timerData = await timerRes.json();
          setTimer(timerData.timer);
        }

        // Log success
        await fetch('/api/logs', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            prompt: `[Region Edit] ${editPrompt}`,
            model: 'gemini-2.5-flash-image',
            status: 'success',
            image_data: newBase64Image,
            attributes: {
              type: 'region_edit'
            }
          })
        });
      } else {
        throw new Error("No edited image generated");
      }

    } catch (err: any) {
      console.error(err);
      const errMsg = err.message || String(err);
      setError(errMsg);
      
      if (errMsg.includes("Requested entity was not found.")) {
        setHasKey(false);
        if (window.aistudio?.openSelectKey) {
          await window.aistudio.openSelectKey();
        }
      }
    } finally {
      setEditLoading(false);
    }
  };

  const [adminLoginError, setAdminLoginError] = useState('');

  const handleAdminLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (adminPassword === '18190000') {
      setIsAdmin(true);
      setShowAdminLogin(false);
      setAdminLoginError('');
      fetchLogs();
    } else {
      setAdminLoginError('Incorrect password');
    }
  };

  const fetchLogs = async () => {
    try {
      const res = await fetch('/api/logs', {
        headers: { 'x-admin-password': adminPassword }
      });
      if (res.ok) {
        const data = await res.json();
        setLogs(data);
      }
    } catch (e) {
      console.error('Failed to fetch logs', e);
    }
  };

  const handleAddPreset = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPresetName || !newPresetTemplate) return;
    try {
      const res = await fetch('/api/presets', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-admin-password': adminPassword
        },
        body: JSON.stringify({ name: newPresetName, prompt_template: newPresetTemplate })
      });
      if (res.ok) {
        setNewPresetName('');
        setNewPresetTemplate('');
        fetchPresets();
      }
    } catch (e) {
      console.error('Failed to add preset', e);
    }
  };

  const handleDeletePreset = async (id: number) => {
    try {
      const res = await fetch(`/api/presets/${id}`, {
        method: 'DELETE',
        headers: { 'x-admin-password': adminPassword }
      });
      if (res.ok) {
        fetchPresets();
      }
    } catch (e) {
      console.error('Failed to delete preset', e);
    }
  };

  const handleResetTimer = async () => {
    try {
      const res = await fetch('/api/timer/reset', {
        method: 'POST',
        headers: { 
          'x-admin-password': adminPassword,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ timer: adminTimerValue })
      });
      if (res.ok) {
        const data = await res.json();
        setTimer(data.timer);
      }
    } catch (e) {
      console.error('Failed to reset timer', e);
    }
  };

  const handleUpdateStoryboardPrompt = async () => {
    try {
      const res = await fetch('/api/settings/storyboard_prompt', {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json',
          'x-admin-password': adminPassword 
        },
        body: JSON.stringify({ prompt: adminStoryboardPrompt })
      });
      if (res.ok) {
        setStoryboardPromptTemplate(adminStoryboardPrompt);
        console.log('Storyboard prompt updated successfully!');
      } else {
        console.error('Failed to update storyboard prompt');
      }
    } catch (e) {
      console.error('Failed to update storyboard prompt', e);
    }
  };

  const handleUpdateCarouselImages = async () => {
    try {
      const res = await fetch('/api/settings/carousel_images', {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json',
          'x-admin-password': adminPassword 
        },
        body: JSON.stringify({ images: adminCarouselImages })
      });
      if (res.ok) {
        setCarouselImages(adminCarouselImages);
        console.log('Carousel images updated successfully!');
      } else {
        console.error('Failed to update carousel images');
      }
    } catch (e) {
      console.error('Failed to update carousel images', e);
    }
  };

  const handleAdminCarouselImageUpload = (index: number, e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onloadend = () => {
      const newImages = [...adminCarouselImages];
      newImages[index] = reader.result as string;
      setAdminCarouselImages(newImages);
    };
    reader.readAsDataURL(file);
  };

  const handleAutopilotImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onloadend = () => {
      setAutopilotImage(reader.result as string);
    };
    reader.readAsDataURL(file);
  };

  const analyzeAutopilotImage = async () => {
    if (!autopilotImage || timer === null || timer <= 0) return;
    setAutopilotLoading(true);
    setError(null);
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || process.env.GEMINI_API_KEY });
      
      const base64Data = autopilotImage.split(',')[1];
      const mimeType = autopilotImage.split(';')[0].split(':')[1];

      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: {
          parts: [
            {
              inlineData: {
                data: base64Data,
                mimeType: mimeType
              }
            },
            { text: "Analyze this image and write a detailed prompt that can be used to generate a similar image in terms of style, lighting, composition, and content. Return ONLY the prompt text, nothing else." }
          ]
        }
      });

      if (response.text) {
        setPrompt(response.text.trim());
        
        // Decrement timer
        const timerRes = await fetch('/api/timer/decrement', { method: 'POST' });
        if (timerRes.ok) {
          const timerData = await timerRes.json();
          setTimer(timerData.timer);
        }
      }
    } catch (err: any) {
      console.error(err);
      setError(err.message || String(err));
    } finally {
      setAutopilotLoading(false);
    }
  };

  const generateImage = async () => {
    if (!prompt || timer === null || timer <= 0) return;
    setLoading(true);
    setError(null);
    setImageUrl(null);

    let finalPrompt = prompt;
    if (selectedPresetId && selectedPresetId !== 'autopilot') {
      const preset = presets.find(p => p.id === Number(selectedPresetId));
      if (preset) {
        finalPrompt = preset.prompt_template.replace('{prompt}', prompt);
      }
    }

    if (outcome === 'storyboard') {
      if (storyboardPromptTemplate) {
        finalPrompt = storyboardPromptTemplate.replace('【INPUT】', finalPrompt);
      } else {
        finalPrompt = `Analyze the input image and identify the main subject(s). Maintain perfect consistency in
appearance, proportions, materials, colors, and style across all frames.
Read the SCENE INPUT and generate a cinematic 9-scene sequence that progresses logically
from start to finish. Each frame should represent the next meaningful moment based on the
scene description.
The AI chooses all camera angles and framing automatically.
Ensure cinematic lighting, consistent color grading, realistic depth of field, and coherent
environmental evolution. No repeated shots.
SCENE INPUT: ${finalPrompt}
Frame 1:
Frame 2:
Frame 3:
Frame 4:
Frame 5:
Frame 6:
Frame 7:
Frame 8:
Frame 9:`;
      }
    }

    // Append aspect ratio to prompt
    finalPrompt += `\n\nAspect Ratio: ${aspectRatio}`;

    try {
      // Create new instance right before call
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || process.env.GEMINI_API_KEY });
      
      const parts: any[] = [];
      
      if (imageReferences.length > 0) {
        imageReferences.forEach(ref => {
          if (!ref.file || !ref.attributeName) return;
          const base64Data = ref.file.split(',')[1];
          const mimeType = ref.file.split(';')[0].split(':')[1];
          parts.push({ text: `Reference image for [${ref.attributeName}] (Influence: ${ref.influence} - ${ref.influence === 'Low' ? 'around 30% resemblance' : 'close to 100% resemblance'}):` });
          parts.push({
            inlineData: {
              data: base64Data,
              mimeType: mimeType
            }
          });
        });
        parts.push({ text: `Generate an image based on the following prompt, incorporating the reference images above according to their attribute names and influence levels:\n\nPrompt: ${finalPrompt}` });
      } else {
        parts.push({ text: finalPrompt });
      }

      const response = await ai.models.generateContent({
        model: selectedModel,
        contents: {
          parts: parts
        },
        config: {
          imageConfig: {
            aspectRatio: aspectRatio,
            imageSize: imageSize
          }
        }
      });

      let base64Image = null;
      if (response.candidates?.[0]?.content?.parts) {
        for (const part of response.candidates[0].content.parts) {
          if (part.inlineData) {
            base64Image = `data:${part.inlineData.mimeType};base64,${part.inlineData.data}`;
            break;
          }
        }
      }

      if (base64Image) {
        setImageUrl(base64Image);
        
        // Decrement timer
        const timerRes = await fetch('/api/timer/decrement', { method: 'POST' });
        if (timerRes.ok) {
          const timerData = await timerRes.json();
          setTimer(timerData.timer);
        }

        // Log success
        await fetch('/api/logs', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            prompt: finalPrompt,
            model: selectedModel,
            status: 'success',
            image_data: base64Image,
            attributes: {
              aspectRatio,
              imageSize,
              preset: selectedPresetId,
              outcome,
              imageReferencesCount: imageReferences.length
            }
          })
        });
      } else {
        throw new Error("No image generated");
      }

    } catch (err: any) {
      console.error(err);
      const errMsg = err.message || String(err);
      setError(errMsg);
      
      if (errMsg.includes("Requested entity was not found.")) {
        setHasKey(false);
        if (window.aistudio?.openSelectKey) {
          await window.aistudio.openSelectKey();
        }
      }

      // Log error
      await fetch('/api/logs', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: finalPrompt,
          model: selectedModel,
          status: 'error',
          error: errMsg,
          attributes: {
            aspectRatio,
            imageSize,
            preset: selectedPresetId,
            outcome,
            imageReferencesCount: imageReferences.length
          }
        })
      });
    } finally {
      setLoading(false);
    }
  };

  const handleAddReference = () => {
    setImageReferences([...imageReferences, {
      id: Math.random().toString(36).substring(7),
      file: '',
      attributeName: '',
      influence: 'Low'
    }]);
  };

  const handleAdd3DGSReference = (base64Image: string) => {
    setImageReferences([...imageReferences, {
      id: Math.random().toString(36).substring(7),
      file: base64Image,
      attributeName: '3DGS Capture',
      influence: 'High'
    }]);
    setShowGsplatViewer(false);
  };

  const handleReferenceUpload = (id: string, e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onloadend = () => {
      setImageReferences(refs => refs.map(r => r.id === id ? { ...r, file: reader.result as string } : r));
    };
    reader.readAsDataURL(file);
  };

  const updateReference = (id: string, field: keyof ImageReference, value: string) => {
    setImageReferences(refs => refs.map(r => r.id === id ? { ...r, [field]: value } : r));
  };

  const removeReference = (id: string) => {
    setImageReferences(refs => refs.filter(r => r.id !== id));
  };

  if (showAdminLogin) {
    return (
      <div className="min-h-screen bg-universe flex items-center justify-center p-4">
        <div className="glass-panel p-8 rounded-2xl w-full max-w-md">
          <h2 className="text-2xl font-semibold mb-6 text-white glow-text">Admin Login</h2>
          <form onSubmit={handleAdminLogin} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-zinc-300 mb-1">Password</label>
              <input
                type="password"
                value={adminPassword}
                onChange={(e) => setAdminPassword(e.target.value)}
                className={cn("w-full px-4 py-2 border border-white/10 rounded-xl bg-black/50 text-white outline-none", currentTheme.ring)}
                autoFocus
              />
              {adminLoginError && (
                <p className="text-red-500 text-sm mt-2">{adminLoginError}</p>
              )}
            </div>
            <div className="flex gap-3">
              <button
                type="button"
                onClick={() => setShowAdminLogin(false)}
                className="flex-1 px-4 py-2 border border-white/10 text-zinc-300 rounded-xl hover:bg-white/5 transition-colors"
              >
                Cancel
              </button>
              <button
                type="submit"
                className={cn("flex-1 px-4 py-2 text-white rounded-xl transition-colors glow-border border-none bg-gradient-to-r", currentTheme.bg, currentTheme.hover)}
              >
                Login
              </button>
            </div>
          </form>
        </div>
      </div>
    );
  }

  if (isAdmin) {
    return (
      <div className="min-h-screen bg-universe text-zinc-100">
        <header className="glass-panel border-b border-white/10 px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Settings className={cn("w-5 h-5", currentTheme.text)} />
            <h1 className="text-xl font-semibold text-white glow-text">Admin Dashboard</h1>
          </div>
          <button
            onClick={() => {
              setIsAdmin(false);
              setAdminPassword('');
            }}
            className="flex items-center gap-2 text-sm text-zinc-400 hover:text-white transition-colors"
          >
            <LogOut className="w-4 h-4" />
            Exit Admin
          </button>
        </header>

        <main className="max-w-6xl mx-auto p-6">
          <div className="flex gap-4 mb-8">
            <button
              onClick={() => setAdminTab('presets')}
              className={cn(
                "px-4 py-2 rounded-xl text-sm font-medium transition-colors",
                adminTab === 'presets' ? cn("text-white glow-border bg-gradient-to-r", currentTheme.bg) : "bg-black/40 text-zinc-400 border border-white/10 hover:bg-black/60"
              )}
            >
              Manage Presets
            </button>
            <button
              onClick={() => {
                setAdminTab('logs');
                fetchLogs();
              }}
              className={cn(
                "px-4 py-2 rounded-xl text-sm font-medium transition-colors",
                adminTab === 'logs' ? cn("text-white glow-border bg-gradient-to-r", currentTheme.bg) : "bg-black/40 text-zinc-400 border border-white/10 hover:bg-black/60"
              )}
            >
              View Logs
            </button>
            <button
              onClick={() => setAdminTab('settings')}
              className={cn(
                "px-4 py-2 rounded-xl text-sm font-medium transition-colors",
                adminTab === 'settings' ? cn("text-white glow-border bg-gradient-to-r", currentTheme.bg) : "bg-black/40 text-zinc-400 border border-white/10 hover:bg-black/60"
              )}
            >
              Settings
            </button>
          </div>

          {adminTab === 'presets' && (
            <div className="space-y-6">
              <div className="glass-panel p-6 rounded-2xl">
                <h2 className="text-lg font-semibold mb-4 text-white">Add New Preset</h2>
                <form onSubmit={handleAddPreset} className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-zinc-300 mb-1">Preset Name</label>
                    <input
                      type="text"
                      value={newPresetName}
                      onChange={(e) => setNewPresetName(e.target.value)}
                      className={cn("w-full px-4 py-2 border border-white/10 rounded-xl bg-black/50 text-white outline-none", currentTheme.ring)}
                      placeholder="e.g. Cyberpunk"
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-zinc-300 mb-1">Prompt Template (use {'{prompt}'} as placeholder)</label>
                    <textarea
                      value={newPresetTemplate}
                      onChange={(e) => setNewPresetTemplate(e.target.value)}
                      className={cn("w-full px-4 py-2 border border-white/10 rounded-xl bg-black/50 text-white outline-none h-24 resize-none", currentTheme.ring)}
                      placeholder="cyberpunk style, neon lights, {prompt}"
                      required
                    />
                  </div>
                  <button
                    type="submit"
                    className={cn("flex items-center gap-2 px-4 py-2 text-white rounded-xl transition-colors glow-border bg-gradient-to-r", currentTheme.bg, currentTheme.hover)}
                  >
                    <Plus className="w-4 h-4" />
                    Add Preset
                  </button>
                </form>
              </div>

              <div className="glass-panel rounded-2xl overflow-hidden">
                <table className="w-full text-left text-sm">
                  <thead className="bg-black/40 border-b border-white/10 text-zinc-400">
                    <tr>
                      <th className="px-6 py-3 font-medium">Name</th>
                      <th className="px-6 py-3 font-medium">Template</th>
                      <th className="px-6 py-3 font-medium w-24">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-white/10">
                    {presets.map(preset => (
                      <tr key={preset.id} className="hover:bg-white/5">
                        <td className="px-6 py-4 font-medium text-zinc-200">{preset.name}</td>
                        <td className="px-6 py-4 text-zinc-400 font-mono text-xs">{preset.prompt_template}</td>
                        <td className="px-6 py-4">
                          <button
                            onClick={() => handleDeletePreset(preset.id)}
                            className="text-red-400 hover:text-red-300 p-2 hover:bg-red-900/20 rounded-lg transition-colors"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </td>
                      </tr>
                    ))}
                    {presets.length === 0 && (
                      <tr>
                        <td colSpan={3} className="px-6 py-8 text-center text-zinc-500">No presets found.</td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {adminTab === 'logs' && (
            <div className="glass-panel rounded-2xl overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full text-left text-sm">
                  <thead className="bg-black/40 border-b border-white/10 text-zinc-400">
                    <tr>
                      <th className="px-6 py-3 font-medium">Time</th>
                      <th className="px-6 py-3 font-medium">Model</th>
                      <th className="px-6 py-3 font-medium">Prompt</th>
                      <th className="px-6 py-3 font-medium">Attributes</th>
                      <th className="px-6 py-3 font-medium">Status</th>
                      <th className="px-6 py-3 font-medium">Result</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-white/10">
                    {logs.map(log => (
                      <tr key={log.id} className="hover:bg-white/5">
                        <td className="px-6 py-4 text-zinc-500 whitespace-nowrap">
                          {new Date(log.timestamp).toLocaleString()}
                        </td>
                        <td className="px-6 py-4 text-zinc-300">
                          {log.model === 'gemini-3-pro-image-preview' ? 'Banana Pro' : 'Banana 2'}
                        </td>
                        <td className="px-6 py-4 text-zinc-400 max-w-xs truncate" title={log.prompt}>
                          {log.prompt}
                        </td>
                        <td className="px-6 py-4 text-xs text-zinc-500 max-w-[200px]">
                          {log.attributes ? (
                            <div className="space-y-1">
                              {(() => {
                                try {
                                  const attrs = JSON.parse(log.attributes);
                                  return Object.entries(attrs).map(([key, value]) => (
                                    <div key={key} className="flex gap-2">
                                      <span className="text-zinc-400">{key}:</span>
                                      <span className="text-zinc-300 truncate" title={String(value)}>{String(value)}</span>
                                    </div>
                                  ));
                                } catch (e) {
                                  return <span>{log.attributes}</span>;
                                }
                              })()}
                            </div>
                          ) : (
                            <span>-</span>
                          )}
                        </td>
                        <td className="px-6 py-4">
                          <span className={cn(
                            "px-2 py-1 rounded-full text-xs font-medium",
                            log.status === 'success' ? "bg-emerald-900/30 text-emerald-400 border border-emerald-500/30" : "bg-red-900/30 text-red-400 border border-red-500/30"
                          )}>
                            {log.status}
                          </span>
                          {log.error && (
                            <p className="text-xs text-red-400 mt-1 max-w-xs truncate" title={log.error}>{log.error}</p>
                          )}
                        </td>
                        <td className="px-6 py-4">
                          {log.image_data ? (
                            <img src={log.image_data} alt="Generated" className="w-16 h-16 object-cover rounded-lg border border-white/10" referrerPolicy="no-referrer" />
                          ) : (
                            <span className="text-zinc-500 text-xs">No image</span>
                          )}
                        </td>
                      </tr>
                    ))}
                    {logs.length === 0 && (
                      <tr>
                        <td colSpan={5} className="px-6 py-8 text-center text-zinc-500">No logs found.</td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          )}
          {adminTab === 'settings' && (
            <div className="space-y-6">
              <div className="glass-panel p-6 rounded-2xl">
                <h2 className="text-lg font-semibold mb-4 text-white">API Configuration</h2>
                <div className="flex items-center justify-between p-4 bg-black/30 rounded-xl border border-white/10">
                  <div>
                    <h3 className="font-medium text-zinc-200">API Key Status</h3>
                    <p className="text-sm text-zinc-400 mt-1">
                      {hasKey ? 'A custom API key is currently selected.' : 'Using default platform key (may not support all models).'}
                    </p>
                  </div>
                  <button
                    onClick={handleSelectKey}
                    className={cn("flex items-center gap-2 px-4 py-2 text-white rounded-xl text-sm font-medium transition-colors glow-border bg-gradient-to-r", currentTheme.bg, currentTheme.hover)}
                  >
                    <Key className="w-4 h-4" />
                    {hasKey ? 'Change API Key' : 'Select API Key'}
                  </button>
                </div>
              </div>

              <div className="glass-panel p-6 rounded-2xl">
                <h2 className="text-lg font-semibold mb-4 text-white">System Quota</h2>
                <div className="flex items-center justify-between p-4 bg-black/30 rounded-xl border border-white/10">
                  <div>
                    <h3 className="font-medium text-zinc-200">Generation Timer</h3>
                    <p className="text-sm text-zinc-400 mt-1">
                      Current remaining generations: <span className="font-bold text-white">{timer !== null ? timer : '...'}</span>
                    </p>
                  </div>
                  <div className="flex items-center gap-3">
                    <input
                      type="number"
                      value={adminTimerValue}
                      onChange={(e) => setAdminTimerValue(Number(e.target.value))}
                      className="w-24 px-3 py-2 bg-black/50 border border-white/20 text-white rounded-xl text-sm outline-none focus:border-white/40"
                      min="1"
                    />
                    <button
                      onClick={handleResetTimer}
                      className="px-4 py-2 bg-black/50 border border-white/20 text-zinc-300 rounded-xl text-sm font-medium hover:bg-white/10 transition-colors"
                    >
                      Set Quota
                    </button>
                  </div>
                </div>
              </div>

              <div className="glass-panel p-6 rounded-2xl">
                <h2 className="text-lg font-semibold mb-4 text-white">Storyboard Prompt Template</h2>
                <p className="text-sm text-zinc-400 mb-4">
                  This prompt is used when the "Storyboard" outcome is selected. 
                  Use <code className={cn("bg-black/50 px-1.5 py-0.5 rounded", currentTheme.text)}>【INPUT】</code> as the placeholder for the user's prompt.
                </p>
                <div className="space-y-4">
                  <textarea
                    value={adminStoryboardPrompt}
                    onChange={(e) => setAdminStoryboardPrompt(e.target.value)}
                    className={cn("w-full px-4 py-3 border border-white/10 rounded-xl bg-black/50 text-white outline-none h-64 resize-y font-mono text-sm", currentTheme.ring)}
                    placeholder="Enter storyboard prompt template..."
                  />
                  <div className="flex justify-end">
                    <button
                      onClick={handleUpdateStoryboardPrompt}
                      className={cn("px-6 py-2 text-white rounded-xl text-sm font-medium transition-colors glow-border bg-gradient-to-r", currentTheme.bg, currentTheme.hover)}
                    >
                      Save Prompt
                    </button>
                  </div>
                </div>
              </div>

              <div className="glass-panel p-6 rounded-2xl">
                <h2 className="text-lg font-semibold mb-4 text-white">Background Carousel Images</h2>
                <p className="text-sm text-zinc-400 mb-4">
                  Upload 4 images to be used in the background carousel.
                </p>
                <div className="grid grid-cols-2 gap-4 mb-4">
                  {[0, 1, 2, 3].map((index) => (
                    <div key={index} className="relative aspect-video bg-black/40 rounded-xl border border-white/10 overflow-hidden group">
                      {adminCarouselImages[index] ? (
                        <img src={adminCarouselImages[index]} alt={`Carousel ${index + 1}`} className="w-full h-full object-cover" />
                      ) : (
                        <div className="absolute inset-0 flex items-center justify-center text-zinc-500">
                          <ImageIcon className="w-8 h-8 opacity-50" />
                        </div>
                      )}
                      <label className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 flex items-center justify-center cursor-pointer transition-opacity">
                        <span className="text-sm font-medium text-white bg-black/50 px-3 py-1.5 rounded-lg border border-white/20">Change Image</span>
                        <input type="file" accept="image/*" className="hidden" onChange={(e) => handleAdminCarouselImageUpload(index, e)} />
                      </label>
                    </div>
                  ))}
                </div>
                <div className="flex justify-end">
                  <button
                    onClick={handleUpdateCarouselImages}
                    className={cn("px-6 py-2 text-white rounded-xl text-sm font-medium transition-colors glow-border bg-gradient-to-r", currentTheme.bg, currentTheme.hover)}
                  >
                    Save Carousel Images
                  </button>
                </div>
              </div>
            </div>
          )}
        </main>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-black flex items-center justify-center overflow-hidden">
      <div 
        className="relative bg-universe text-zinc-100 font-sans overflow-y-auto overflow-x-hidden origin-center"
        style={{ 
          width: '1920px', 
          height: '1080px', 
          transform: `scale(${scale})` 
        }}
      >
        {/* Starry background elements */}
      <div className="fixed inset-0 pointer-events-none z-0 opacity-50">
        <div className="absolute top-1/4 left-1/4 w-1 h-1 bg-white rounded-full animate-pulse-glow" style={{ animationDelay: '0s' }}></div>
        <div className="absolute top-3/4 left-1/3 w-1.5 h-1.5 bg-white rounded-full animate-pulse-glow" style={{ animationDelay: '1s' }}></div>
        <div className="absolute top-1/3 right-1/4 w-1 h-1 bg-white rounded-full animate-pulse-glow" style={{ animationDelay: '0.5s' }}></div>
        <div className={cn("absolute top-2/3 right-1/3 w-2 h-2 rounded-full animate-pulse-glow opacity-30", currentTheme.bg.split(' ')[0].replace('from-', 'bg-'))} style={{ animationDelay: '1.5s' }}></div>
      </div>

      {/* Carousel Background */}
      <div className="fixed inset-0 z-0 pointer-events-none overflow-hidden">
        {carouselImages.map((img, index) => (
          <div
            key={index}
            className={cn(
              "absolute inset-0 bg-cover bg-center transition-opacity duration-1000",
              index === currentImageIndex ? "opacity-30" : "opacity-0"
            )}
            style={{ backgroundImage: `url(${img})` }}
          />
        ))}
        <div className="absolute inset-0 bg-black/50 backdrop-blur-sm"></div>
      </div>

      <AnimatePresence>
        {showSplash && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0, backdropFilter: "blur(0px)" }}
            transition={{ duration: 0.5 }}
            className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-2xl"
          >
            <motion.div
              className="flex flex-col items-center justify-center gap-8"
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ duration: 1, ease: "easeOut" }}
            >
              <motion.div
                className={cn("w-24 h-24 rounded-3xl flex items-center justify-center shadow-2xl backdrop-blur-xl border border-white/20 bg-gradient-to-br", currentTheme.bg)}
                initial={{ rotate: -20, scale: 0.5, opacity: 0 }}
                animate={{ rotate: 0, scale: 1, opacity: 1 }}
                transition={{ type: "spring", damping: 15, stiffness: 100, delay: 0.1 }}
              >
                <ImageIcon className="w-12 h-12 text-white" />
              </motion.div>
              
              <motion.h1
                className={cn("text-5xl md:text-7xl font-bold tracking-tight text-center px-4 bg-clip-text text-transparent bg-gradient-to-r glow-text", currentTheme.bg)}
                variants={{
                  hidden: { opacity: 1 },
                  visible: {
                    opacity: 1,
                    transition: { staggerChildren: 0.08, delayChildren: 0.3 },
                  },
                }}
                initial="hidden"
                animate="visible"
              >
                {Array.from("Overseas Squad AIGC Platform").map((letter, index) => (
                  <motion.span
                    key={index}
                    variants={{
                      hidden: { opacity: 0, y: 40, filter: "blur(10px)" },
                      visible: {
                        opacity: 1,
                        y: 0,
                        filter: "blur(0px)",
                        transition: { type: "spring", damping: 12, stiffness: 100 },
                      },
                    }}
                    className="inline-block"
                  >
                    {letter === " " ? "\u00A0" : letter}
                  </motion.span>
                ))}
              </motion.h1>

              <motion.div 
                className="h-1 w-32 rounded-full bg-gradient-to-r from-transparent via-white/50 to-transparent"
                initial={{ scaleX: 0, opacity: 0 }}
                animate={{ scaleX: 1, opacity: 1 }}
                transition={{ duration: 1, delay: 2.8, ease: "easeInOut" }}
              />
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      <header className="glass-panel border-b border-white/10 px-6 py-4 flex items-center justify-between sticky top-0 z-10 relative">
        <div className="flex items-center gap-3">
          <div 
            className={cn("w-10 h-10 rounded-xl flex items-center justify-center cursor-pointer glow-border bg-gradient-to-br", currentTheme.bg)}
            onDoubleClick={() => setShowAdminLogin(true)}
            title="Double click for admin"
          >
            <ImageIcon className="w-5 h-5 text-white" />
          </div>
          <div>
            <h1 className="text-xl font-semibold tracking-tight text-white glow-text">Internal AIGC Platform</h1>
            <p className="text-xs text-zinc-400 mt-0.5">Developed by Oliver Huang</p>
          </div>
        </div>
        
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2 px-3 py-1.5 bg-black/40 text-zinc-300 rounded-full text-sm font-medium border border-white/10">
            <span className={cn("w-2 h-2 rounded-full animate-pulse-glow", currentTheme.bg.split(' ')[0].replace('from-', 'bg-'))} />
            Remaining: {timer !== null ? timer : '...'}
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto p-6 lg:p-12 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          
          <div className="lg:col-span-4 space-y-6">
            <div className="glass-panel p-6 rounded-2xl space-y-6">
              
              <div>
                <label className="block text-sm font-medium text-zinc-300 mb-2">Model</label>
                <div className="grid grid-cols-2 gap-3">
                  <button
                    onClick={() => setSelectedModel('gemini-3-pro-image-preview')}
                    className={cn(
                      "px-4 py-3 rounded-xl text-sm font-medium border text-center transition-all",
                      selectedModel === 'gemini-3-pro-image-preview' 
                        ? cn("bg-gradient-to-r glow-border", currentTheme.border, currentTheme.text, currentTheme.bg.replace('from-', 'from-').replace('to-', 'to-').replace(/-\d00/g, '-600/20')) 
                        : "border-white/10 bg-black/40 text-zinc-400 hover:border-white/20 hover:bg-black/60"
                    )}
                  >
                    Banana Pro
                  </button>
                  <button
                    onClick={() => setSelectedModel('gemini-3.1-flash-image-preview')}
                    className={cn(
                      "px-4 py-3 rounded-xl text-sm font-medium border text-center transition-all",
                      selectedModel === 'gemini-3.1-flash-image-preview' 
                        ? cn("bg-gradient-to-r glow-border", currentTheme.border, currentTheme.text, currentTheme.bg.replace('from-', 'from-').replace('to-', 'to-').replace(/-\d00/g, '-600/20')) 
                        : "border-white/10 bg-black/40 text-zinc-400 hover:border-white/20 hover:bg-black/60"
                    )}
                  >
                    Banana 2
                  </button>
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-zinc-300 mb-2">Outcome</label>
                <div className="grid grid-cols-2 gap-3">
                  <button
                    onClick={() => setOutcome('single')}
                    className={cn(
                      "px-4 py-3 rounded-xl text-sm font-medium border text-center transition-all",
                      outcome === 'single' 
                        ? cn("bg-gradient-to-r glow-border", currentTheme.border, currentTheme.text, currentTheme.bg.replace('from-', 'from-').replace('to-', 'to-').replace(/-\d00/g, '-600/20')) 
                        : "border-white/10 bg-black/40 text-zinc-400 hover:border-white/20 hover:bg-black/60"
                    )}
                  >
                    Single Image
                  </button>
                  <button
                    onClick={() => setOutcome('storyboard')}
                    className={cn(
                      "px-4 py-3 rounded-xl text-sm font-medium border text-center transition-all",
                      outcome === 'storyboard' 
                        ? cn("bg-gradient-to-r glow-border", currentTheme.border, currentTheme.text, currentTheme.bg.replace('from-', 'from-').replace('to-', 'to-').replace(/-\d00/g, '-600/20')) 
                        : "border-white/10 bg-black/40 text-zinc-400 hover:border-white/20 hover:bg-black/60"
                    )}
                  >
                    Storyboard
                  </button>
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-zinc-300 mb-2">Style Preset</label>
                <select
                  value={selectedPresetId}
                  onChange={(e) => {
                    const val = e.target.value;
                    setSelectedPresetId(val === 'autopilot' ? 'autopilot' : (val ? Number(val) : ''));
                  }}
                  className={cn("w-full px-4 py-3 border border-white/10 rounded-xl bg-black/50 text-white outline-none appearance-none cursor-pointer", currentTheme.ring)}
                >
                  <option value="" className="bg-zinc-900">None (Raw Prompt)</option>
                  <option value="autopilot" className="bg-zinc-900">Autopilot (Analyze Image)</option>
                  {presets.map(p => (
                    <option key={p.id} value={p.id} className="bg-zinc-900">{p.name}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-zinc-300 mb-2">Aspect Ratio</label>
                <select
                  value={aspectRatio}
                  onChange={(e) => setAspectRatio(e.target.value)}
                  className={cn("w-full px-4 py-3 border border-white/10 rounded-xl bg-black/50 text-white outline-none appearance-none cursor-pointer", currentTheme.ring)}
                >
                  <option value="1:1" className="bg-zinc-900">1:1 (Square)</option>
                  <option value="16:9" className="bg-zinc-900">16:9 (Landscape)</option>
                  <option value="9:16" className="bg-zinc-900">9:16 (Portrait)</option>
                  <option value="4:3" className="bg-zinc-900">4:3 (Landscape)</option>
                  <option value="3:4" className="bg-zinc-900">3:4 (Portrait)</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-zinc-300 mb-2">Resolution (Image Size)</label>
                <select
                  value={imageSize}
                  onChange={(e) => setImageSize(e.target.value)}
                  className={cn("w-full px-4 py-3 border border-white/10 rounded-xl bg-black/50 text-white outline-none appearance-none cursor-pointer", currentTheme.ring)}
                >
                  {selectedModel === 'gemini-3.1-flash-image-preview' && (
                    <option value="512px" className="bg-zinc-900">512px (Fast)</option>
                  )}
                  <option value="1K" className="bg-zinc-900">1K (Standard)</option>
                  <option value="2K" className="bg-zinc-900">2K (High Quality)</option>
                  <option value="4K" className="bg-zinc-900">4K (Ultra HD)</option>
                </select>
              </div>

              {selectedPresetId === 'autopilot' && (
                <div className="p-4 bg-black/30 border border-white/10 rounded-xl space-y-4">
                  <h3 className="text-sm font-medium text-zinc-300">Upload an image to analyze its style</h3>
                  
                  <div className="flex items-center justify-center w-full">
                    <label className="flex flex-col items-center justify-center w-full h-32 border-2 border-white/20 border-dashed rounded-xl cursor-pointer bg-black/40 hover:bg-black/60 transition-colors relative overflow-hidden">
                      {autopilotImage ? (
                        <img src={autopilotImage} alt="Upload preview" className="absolute inset-0 w-full h-full object-cover opacity-50" />
                      ) : (
                        <div className="flex flex-col items-center justify-center pt-5 pb-6">
                          <Upload className="w-8 h-8 mb-3 text-zinc-500" />
                          <p className="mb-2 text-sm text-zinc-400"><span className={cn("font-semibold", currentTheme.text)}>Click to upload</span></p>
                        </div>
                      )}
                      <input type="file" className="hidden" accept="image/*" onChange={handleAutopilotImageUpload} />
                    </label>
                  </div>

                  <button
                    onClick={analyzeAutopilotImage}
                    disabled={!autopilotImage || autopilotLoading || timer === null || timer <= 0}
                    className={cn("w-full py-2 text-white rounded-lg text-sm font-medium transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2 glow-border border-none bg-gradient-to-r", currentTheme.bg, currentTheme.hover)}
                  >
                    {autopilotLoading ? (
                      <>
                        <div className="w-4 h-4 rounded-full border-2 border-white/20 border-t-white animate-spin" />
                        Analyzing...
                      </>
                    ) : (
                      'Analyze Style & Generate Prompt'
                    )}
                  </button>
                </div>
              )}

              <div>
                <label className="block text-sm font-medium text-zinc-300 mb-2">Prompt</label>
                <textarea
                  value={prompt}
                  onChange={(e) => setPrompt(e.target.value)}
                  placeholder="Describe the image you want to generate..."
                  className={cn("w-full px-4 py-3 border border-white/10 rounded-xl bg-black/50 text-white placeholder-zinc-600 outline-none h-32 resize-none", currentTheme.ring)}
                />
              </div>

              <button
                onClick={generateImage}
                disabled={!prompt || loading || timer === null || timer <= 0}
                className={cn("w-full py-3.5 text-white rounded-xl font-medium transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2 glow-border border-none bg-gradient-to-r", currentTheme.bg, currentTheme.hover)}
              >
                {loading ? (
                  <>
                    <div className="w-5 h-5 rounded-full border-2 border-white/20 border-t-white animate-spin" />
                    Generating...
                  </>
                ) : (
                  <>
                    <ImageIcon className="w-5 h-5" />
                    {timer !== null && timer <= 0 ? 'Quota Exceeded' : 'Generate Image'}
                  </>
                )}
              </button>
              
              {timer !== null && timer <= 0 && (
                <p className="text-xs text-red-400 text-center mt-2">
                  Generation limit reached. Please contact the administrator.
                </p>
              )}
            </div>
          </div>

          <div className="lg:col-span-3 space-y-6">
            <div className="glass-panel p-6 rounded-2xl space-y-6">
              <div>
                <div className="flex items-center justify-between mb-2">
                  <label className="block text-sm font-medium text-zinc-300">Image References</label>
                  <div className="flex items-center gap-3">
                    <button
                      onClick={() => setShowGsplatViewer(true)}
                      className={cn("text-xs flex items-center gap-1 transition-colors", currentTheme.text, currentTheme.hover.replace('bg-', 'text-').replace('from-', 'text-').replace('to-', 'text-'))}
                    >
                      <Box className="w-3 h-3" /> Upload 3D Model
                    </button>
                    <button
                      onClick={handleAddReference}
                      className={cn("text-xs flex items-center gap-1 transition-colors", currentTheme.text, currentTheme.hover.replace('bg-', 'text-').replace('from-', 'text-').replace('to-', 'text-'))}
                    >
                      <Plus className="w-3 h-3" /> Add Reference
                    </button>
                  </div>
                </div>
                
                {imageReferences.length === 0 ? (
                  <div className="text-center p-6 border border-white/10 border-dashed rounded-xl bg-black/30">
                    <p className="text-sm text-zinc-400">No references added.</p>
                    <p className="text-xs text-zinc-500 mt-1">Add images to guide the generation style.</p>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {imageReferences.map((ref, index) => (
                      <div key={ref.id} className="p-4 bg-black/30 border border-white/10 rounded-xl relative">
                        <button
                          onClick={() => removeReference(ref.id)}
                          className="absolute top-2 right-2 text-zinc-500 hover:text-red-400 transition-colors"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                        
                        <div className="flex flex-col gap-3">
                          <div className="w-full h-32 shrink-0">
                            <label className="flex flex-col items-center justify-center w-full h-full border-2 border-white/20 border-dashed rounded-lg cursor-pointer bg-black/40 hover:bg-black/60 transition-colors relative overflow-hidden">
                              {ref.file ? (
                                <img src={ref.file} alt="Reference" className="absolute inset-0 w-full h-full object-cover" />
                              ) : (
                                <div className="flex flex-col items-center justify-center">
                                  <Upload className="w-5 h-5 text-zinc-500" />
                                </div>
                              )}
                              <input type="file" className="hidden" accept="image/*" onChange={(e) => handleReferenceUpload(ref.id, e)} />
                            </label>
                          </div>
                          
                          <div className="space-y-3">
                            <div>
                              <input
                                type="text"
                                value={ref.attributeName}
                                onChange={(e) => updateReference(ref.id, 'attributeName', e.target.value)}
                                placeholder="Attribute Name (e.g. Human)"
                                className={cn("w-full px-3 py-1.5 text-sm border border-white/10 rounded-lg bg-black/50 text-white placeholder-zinc-600 outline-none", currentTheme.ring)}
                              />
                            </div>
                            <div>
                              <select
                                value={ref.influence}
                                onChange={(e) => updateReference(ref.id, 'influence', e.target.value)}
                                className={cn("w-full px-3 py-1.5 text-sm border border-white/10 rounded-lg bg-black/50 text-white outline-none cursor-pointer", currentTheme.ring)}
                              >
                                <option value="Low" className="bg-zinc-900">Influence: Low (~30%)</option>
                                <option value="High" className="bg-zinc-900">Influence: High (~100%)</option>
                              </select>
                            </div>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          </div>

          <div className="lg:col-span-5">
            <div className="glass-panel rounded-2xl aspect-square flex flex-col items-center justify-center overflow-hidden relative">
              {loading ? (
                <div className={cn("flex flex-col items-center gap-6", currentTheme.text)}>
                  <div className="black-hole-loader"></div>
                  <p className="font-medium animate-pulse glow-text">Crafting your universe...</p>
                </div>
              ) : imageUrl ? (
                <div className="relative w-full h-full flex items-center justify-center">
                  <img 
                    ref={imageRef}
                    src={imageUrl} 
                    alt="Generated result" 
                    className="max-w-full max-h-full object-contain"
                    referrerPolicy="no-referrer"
                    draggable={false}
                  />
                  {isEditingRegion && (
                    <canvas
                      ref={canvasRef}
                      className="absolute z-10 cursor-crosshair touch-none"
                      style={{
                        top: imageRef.current ? `${imageRef.current.offsetTop}px` : 0,
                        left: imageRef.current ? `${imageRef.current.offsetLeft}px` : 0,
                      }}
                      onMouseDown={startDrawing}
                      onMouseMove={draw}
                      onMouseUp={stopDrawing}
                      onMouseLeave={stopDrawing}
                      onTouchStart={startDrawing}
                      onTouchMove={draw}
                      onTouchEnd={stopDrawing}
                    />
                  )}
                </div>
              ) : error ? (
                <div className="p-8 text-center">
                  <div className="w-12 h-12 bg-red-900/50 text-red-400 rounded-full flex items-center justify-center mx-auto mb-4 border border-red-500/30">
                    <span className="text-xl font-bold">!</span>
                  </div>
                  <h3 className="text-lg font-medium text-zinc-200 mb-2">Generation Failed</h3>
                  <p className="text-sm text-zinc-400 max-w-sm mx-auto">{error}</p>
                </div>
              ) : (
                <div className="text-center text-zinc-600 p-8">
                  <ImageIcon className="w-16 h-16 mx-auto mb-4 opacity-20" />
                  <p className="font-medium">Your generated image will appear here</p>
                </div>
              )}
            </div>
            
            {imageUrl && !loading && (
              <div className="mt-4 flex flex-col gap-4">
                {!isEditingRegion ? (
                  <div className="flex justify-end gap-3">
                    <button 
                      onClick={() => setIsEditingRegion(true)}
                      className="px-4 py-2 bg-black/40 border border-white/10 text-zinc-300 rounded-xl text-sm font-medium hover:bg-white/5 hover:text-white transition-colors flex items-center gap-2"
                    >
                      <Brush className="w-4 h-4" />
                      Local Edit
                    </button>
                    <a 
                      href={imageUrl} 
                      download="generated-image.png"
                      className="px-4 py-2 glass-panel text-zinc-300 rounded-xl text-sm font-medium hover:bg-white/5 hover:text-white transition-colors shadow-sm"
                    >
                      Download Image
                    </a>
                  </div>
                ) : (
                  <div className="glass-panel p-4 rounded-xl space-y-4 animate-in fade-in slide-in-from-bottom-4">
                    <div className="flex items-center justify-between">
                      <h3 className={cn("text-sm font-medium flex items-center gap-2", currentTheme.text)}>
                        <Brush className="w-4 h-4" /> Draw over the area to edit
                      </h3>
                      <div className="flex items-center gap-2">
                        <button 
                          onClick={clearCanvas}
                          className="text-xs text-zinc-400 hover:text-white px-2 py-1 rounded bg-black/40"
                        >
                          Clear Brush
                        </button>
                        <button 
                          onClick={() => setIsEditingRegion(false)}
                          className="text-zinc-400 hover:text-white p-1"
                        >
                          <X className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                    
                    <div className="flex gap-2">
                      <input
                        type="text"
                        value={editPrompt}
                        onChange={(e) => setEditPrompt(e.target.value)}
                        placeholder="What should be in the highlighted area?"
                        className={cn("flex-1 px-3 py-2 border border-white/10 rounded-lg bg-black/50 text-white text-sm outline-none", currentTheme.ring)}
                      />
                      <button
                        onClick={handleEditRegion}
                        disabled={!editPrompt || editLoading || timer === null || timer <= 0}
                        className={cn("px-4 py-2 text-white rounded-lg text-sm font-medium transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2 bg-gradient-to-r", currentTheme.bg, currentTheme.hover)}
                      >
                        {editLoading ? (
                          <div className="w-4 h-4 rounded-full border-2 border-white/20 border-t-white animate-spin" />
                        ) : (
                          'Apply Edit'
                        )}
                      </button>
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>

        </div>
      </main>
      </div>
      {showGsplatViewer && (
        <GsplatViewer 
          onScreenshot={handleAdd3DGSReference} 
          onClose={() => setShowGsplatViewer(false)} 
        />
      )}
    </div>
  );
}
