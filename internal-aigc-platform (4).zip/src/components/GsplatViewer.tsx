import React, { useEffect, useRef, useState } from "react";
import * as pc from "playcanvas";
import { Camera, Upload, X } from "lucide-react";
import { cn } from "../utils";

interface GsplatViewerProps {
  onScreenshot: (base64Image: string) => void;
  onClose: () => void;
}

export default function GsplatViewer({
  onScreenshot,
  onClose,
}: GsplatViewerProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [appInstance, setAppInstance] = useState<pc.Application | null>(null);
  const entityRef = useRef<pc.Entity | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Camera controls state
  const isDragging = useRef(false);
  const lastMousePos = useRef({ x: 0, y: 0 });
  const cameraAngles = useRef({ x: 0, y: 0 });
  const cameraDistance = useRef(3);
  const cameraTarget = useRef(new pc.Vec3(0, 0, 0));
  const speedMultiplier = useRef(1);

  const [modelRotation, setModelRotation] = useState({ x: "0", y: "0", z: "0" });
  const [speed, setSpeed] = useState(1);

  useEffect(() => {
    speedMultiplier.current = speed;
  }, [speed]);

  useEffect(() => {
    if (entityRef.current) {
      entityRef.current.setLocalEulerAngles(
        Number(modelRotation.x) || 0, 
        Number(modelRotation.y) || 0, 
        Number(modelRotation.z) || 0
      );
    }
  }, [modelRotation]);

  useEffect(() => {
    if (!canvasRef.current) return;
    const canvas = canvasRef.current;

    // Create application
    const keyboard = new pc.Keyboard(window);
    const app = new pc.Application(canvas, {
      mouse: new pc.Mouse(canvas),
      touch: new pc.TouchDevice(canvas),
      keyboard: keyboard,
      graphicsDeviceOptions: {
        alpha: true,
        preserveDrawingBuffer: true, // Required for taking screenshots
      },
    });

    app.setCanvasFillMode(pc.FILLMODE_NONE);
    app.setCanvasResolution(pc.RESOLUTION_AUTO);
    app.resizeCanvas();

    // Create camera
    const camera = new pc.Entity("camera");
    camera.addComponent("camera", {
      clearColor: new pc.Color(0.1, 0.1, 0.1, 1),
      nearClip: 0.1,
      farClip: 1000,
    });
    app.root.addChild(camera);

    // Initial camera position
    updateCameraPosition(camera);

    // Add light
    const light = new pc.Entity("light");
    light.addComponent("light", {
      type: "directional",
      color: new pc.Color(1, 1, 1),
      castShadows: true,
      intensity: 1,
    });
    light.setLocalEulerAngles(45, 30, 0);
    app.root.addChild(light);

    app.start();
    setAppInstance(app);

    app.on("update", (dt) => {
      if (!app.keyboard) return;

      let moved = false;
      const moveSpeed = (cameraDistance.current * 0.5 + 1) * dt * speedMultiplier.current;

      const ax = cameraAngles.current.x * pc.math.DEG_TO_RAD;
      const forward = new pc.Vec3(-Math.sin(ax), 0, -Math.cos(ax));
      const right = new pc.Vec3(Math.cos(ax), 0, -Math.sin(ax));

      if (app.keyboard.isPressed(pc.KEY_W)) {
        cameraTarget.current.add(forward.clone().mulScalar(moveSpeed));
        moved = true;
      }
      if (app.keyboard.isPressed(pc.KEY_S)) {
        cameraTarget.current.sub(forward.clone().mulScalar(moveSpeed));
        moved = true;
      }
      if (app.keyboard.isPressed(pc.KEY_A)) {
        cameraTarget.current.sub(right.clone().mulScalar(moveSpeed));
        moved = true;
      }
      if (app.keyboard.isPressed(pc.KEY_D)) {
        cameraTarget.current.add(right.clone().mulScalar(moveSpeed));
        moved = true;
      }
      if (app.keyboard.isPressed(pc.KEY_Q)) {
        cameraTarget.current.y -= moveSpeed;
        moved = true;
      }
      if (app.keyboard.isPressed(pc.KEY_E)) {
        cameraTarget.current.y += moveSpeed;
        moved = true;
      }

      if (moved) {
        const camera = app.root.findByName("camera");
        if (camera) {
          updateCameraPosition(camera as pc.Entity);
        }
      }
    });

    const handleResize = () => app.resizeCanvas();
    window.addEventListener("resize", handleResize);

    const resizeObserver = new ResizeObserver(() => {
      app.resizeCanvas();
    });
    if (canvas.parentElement) {
      resizeObserver.observe(canvas.parentElement);
    }

    return () => {
      window.removeEventListener("resize", handleResize);
      resizeObserver.disconnect();
      keyboard.detach();
      app.destroy();
    };
  }, []);

  const updateCameraPosition = (camera: pc.Entity) => {
    const distance = cameraDistance.current;
    const ax = cameraAngles.current.x * pc.math.DEG_TO_RAD;
    const ay = cameraAngles.current.y * pc.math.DEG_TO_RAD;

    const x = distance * Math.sin(ax) * Math.cos(ay);
    const y = distance * Math.sin(ay);
    const z = distance * Math.cos(ax) * Math.cos(ay);

    camera.setPosition(
      cameraTarget.current.x + x,
      cameraTarget.current.y + y,
      cameraTarget.current.z + z,
    );
    camera.lookAt(cameraTarget.current);
  };

  const handleMouseDown = (e: React.MouseEvent) => {
    isDragging.current = true;
    lastMousePos.current = { x: e.clientX, y: e.clientY };
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isDragging.current || !appInstance) return;

    const dx = e.clientX - lastMousePos.current.x;
    const dy = e.clientY - lastMousePos.current.y;

    cameraAngles.current.x -= dx * 0.5;
    cameraAngles.current.y += dy * 0.5;

    // Clamp vertical angle
    cameraAngles.current.y = pc.math.clamp(cameraAngles.current.y, -89, 89);

    lastMousePos.current = { x: e.clientX, y: e.clientY };

    const camera = appInstance.root.findByName("camera");
    if (camera) {
      updateCameraPosition(camera as pc.Entity);
    }
  };

  const handleMouseUp = () => {
    isDragging.current = false;
  };

  const handleWheel = (e: React.WheelEvent) => {
    if (!appInstance) return;

    cameraDistance.current += e.deltaY * 0.01;
    cameraDistance.current = Math.max(0.1, cameraDistance.current);

    const camera = appInstance.root.findByName("camera");
    if (camera) {
      updateCameraPosition(camera as pc.Entity);
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !appInstance) return;

    setLoading(true);
    setError(null);

    const url = URL.createObjectURL(file);

    appInstance.assets.loadFromUrlAndFilename(
      url,
      file.name,
      "gsplat",
      (err, asset) => {
        setLoading(false);
        if (err) {
          console.error("Error loading gsplat:", err);
          setError(
            "Failed to load 3DGS model. Ensure it's a valid .ply, .splat, or .lcc file.",
          );
          return;
        }

        if (entityRef.current) {
          entityRef.current.destroy();
        }

        const entity = new pc.Entity();
        entity.addComponent("gsplat", {
          asset: asset,
        });
        entity.setLocalEulerAngles(
          Number(modelRotation.x) || 0,
          Number(modelRotation.y) || 0,
          Number(modelRotation.z) || 0
        );
        appInstance.root.addChild(entity);
        entityRef.current = entity;

        // Reset camera
        cameraAngles.current = { x: 0, y: 0 };
        cameraDistance.current = 3;
        cameraTarget.current = new pc.Vec3(0, 0, 0);
        const camera = appInstance.root.findByName("camera");
        if (camera) {
          updateCameraPosition(camera as pc.Entity);
        }
      },
    );
  };

  const takeScreenshot = () => {
    if (!canvasRef.current || !appInstance) return;

    // Force a render to ensure we capture the latest state
    appInstance.renderNextFrame = true;

    // Wait for the next frame to be rendered before taking screenshot
    requestAnimationFrame(() => {
      const dataUrl = canvasRef.current?.toDataURL("image/png");
      if (dataUrl) {
        onScreenshot(dataUrl);
      }
    });
  };

  return (
    <div className="fixed inset-0 z-50 flex flex-col md:flex-row items-center justify-center bg-black/80 backdrop-blur-sm p-4 gap-4">
      <div className="bg-zinc-900 border border-white/10 rounded-2xl w-full max-w-5xl h-[60vh] md:h-[80vh] flex flex-col overflow-hidden relative">
        <div className="flex items-center justify-between px-6 py-4 border-b border-white/10 bg-black/40">
          <h3 className="text-lg font-medium text-white">3DGS Viewer</h3>
          <button
            onClick={onClose}
            className="p-2 hover:bg-white/10 rounded-xl transition-colors text-zinc-400 hover:text-white"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div
          className="flex-1 min-h-0 relative bg-black"
          onMouseDown={handleMouseDown}
          onMouseMove={handleMouseMove}
          onMouseUp={handleMouseUp}
          onMouseLeave={handleMouseUp}
          onWheel={handleWheel}
        >
          <canvas ref={canvasRef} className="w-full h-full outline-none" />

          {loading && (
            <div className="absolute inset-0 flex items-center justify-center bg-black/50">
              <div className="text-white flex flex-col items-center gap-2">
                <div className="w-8 h-8 border-4 border-white/20 border-t-white rounded-full animate-spin" />
                <span>Loading Model...</span>
              </div>
            </div>
          )}

          {error && (
            <div className="absolute top-4 left-1/2 -translate-x-1/2 bg-red-500/90 text-white px-4 py-2 rounded-lg text-sm">
              {error}
            </div>
          )}

          <div className="absolute bottom-6 left-1/2 -translate-x-1/2 flex items-center gap-4 bg-black/60 backdrop-blur-md px-6 py-3 rounded-2xl border border-white/10 z-10">
            <label className="flex items-center gap-2 px-4 py-2 bg-white/10 hover:bg-white/20 text-white rounded-xl cursor-pointer transition-colors">
              <Upload className="w-4 h-4" />
              <span className="text-sm font-medium">Upload Model</span>
              <input
                type="file"
                accept=".ply,.splat,.lcc"
                onChange={handleFileUpload}
                className="hidden"
              />
            </label>

            <div className="w-px h-6 bg-white/20" />

            <button
              onClick={takeScreenshot}
              disabled={!entityRef.current}
              className="flex items-center gap-2 px-4 py-2 bg-emerald-500 hover:bg-emerald-400 disabled:bg-zinc-700 disabled:text-zinc-500 text-white rounded-xl transition-colors"
            >
              <Camera className="w-4 h-4" />
              <span className="text-sm font-medium">Capture Reference</span>
            </button>
          </div>

          <div className="absolute top-4 left-4 text-xs text-zinc-500 bg-black/40 px-3 py-1.5 rounded-lg backdrop-blur-sm z-10">
            Drag to rotate • Scroll to zoom • WASD to move • QE for up/down
          </div>
        </div>
      </div>

      <div className="bg-zinc-900 border border-white/10 rounded-2xl w-full md:w-64 h-auto md:h-[80vh] flex flex-col overflow-hidden shrink-0">
        <div className="px-4 py-4 border-b border-white/10 bg-black/40">
          <h3 className="text-sm font-medium text-white">Model Transform</h3>
        </div>
        <div className="p-4 flex flex-col gap-4">
          <div className="space-y-3">
            <label className="text-xs font-medium text-zinc-400">Rotation (Degrees)</label>
            
            <div className="space-y-2">
              <div className="flex items-center gap-2">
                <span className="text-xs font-medium text-red-400 w-4">X</span>
                <input 
                  type="text" 
                  value={modelRotation.x}
                  onChange={(e) => setModelRotation(prev => ({ ...prev, x: e.target.value }))}
                  className="w-full bg-black/40 border border-white/10 rounded-lg px-2 py-1 text-sm text-white outline-none focus:border-white/30"
                />
              </div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-medium text-green-400 w-4">Y</span>
                <input 
                  type="text" 
                  value={modelRotation.y}
                  onChange={(e) => setModelRotation(prev => ({ ...prev, y: e.target.value }))}
                  className="w-full bg-black/40 border border-white/10 rounded-lg px-2 py-1 text-sm text-white outline-none focus:border-white/30"
                />
              </div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-medium text-blue-400 w-4">Z</span>
                <input 
                  type="text" 
                  value={modelRotation.z}
                  onChange={(e) => setModelRotation(prev => ({ ...prev, z: e.target.value }))}
                  className="w-full bg-black/40 border border-white/10 rounded-lg px-2 py-1 text-sm text-white outline-none focus:border-white/30"
                />
              </div>
            </div>
            
            <button 
              onClick={() => setModelRotation({ x: "0", y: "0", z: "0" })}
              className="w-full mt-2 px-3 py-1.5 bg-white/5 hover:bg-white/10 text-xs text-white rounded-lg transition-colors"
            >
              Reset Rotation
            </button>
          </div>

          <div className="h-px bg-white/10 my-2" />

          <div className="space-y-3">
            <label className="text-xs font-medium text-zinc-400 flex justify-between">
              <span>Camera Speed</span>
              <span className="text-white">{speed}x</span>
            </label>
            <input 
              type="range" 
              min="0.1" 
              max="5" 
              step="0.1"
              value={speed}
              onChange={(e) => setSpeed(Number(e.target.value))}
              className="w-full accent-emerald-500"
            />
            <div className="flex justify-between text-[10px] text-zinc-500">
              <span>Slow</span>
              <span>Fast</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
