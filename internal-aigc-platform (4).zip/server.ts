import express from 'express';
import { createServer as createViteServer } from 'vite';
import Database from 'better-sqlite3';
import path from 'path';

const db = new Database('app.db');

db.exec(`
  CREATE TABLE IF NOT EXISTS presets (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    prompt_template TEXT NOT NULL
  );
  CREATE TABLE IF NOT EXISTS logs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
    prompt TEXT NOT NULL,
    model TEXT NOT NULL,
    status TEXT NOT NULL,
    error TEXT,
    image_data TEXT,
    attributes TEXT
  );
  CREATE TABLE IF NOT EXISTS settings (
    key TEXT PRIMARY KEY,
    value TEXT
  );
`);

// Initialize timer
const timerSetting = db.prepare('SELECT value FROM settings WHERE key = ?').get('timer') as { value: string } | undefined;
if (!timerSetting) {
  db.prepare('INSERT INTO settings (key, value) VALUES (?, ?)').run('timer', '100');
}

// Add attributes column to logs if it doesn't exist
try {
  db.prepare('ALTER TABLE logs ADD COLUMN attributes TEXT').run();
} catch (e) {
  // Column already exists
}

// Initialize storyboard prompt
const storyboardPromptSetting = db.prepare('SELECT value FROM settings WHERE key = ?').get('storyboard_prompt') as { value: string } | undefined;
if (!storyboardPromptSetting) {
  const defaultStoryboardPrompt = `Analyze the input image and identify the main subject(s). Maintain perfect consistency in
appearance, proportions, materials, colors, and style across all frames.
Read the SCENE INPUT and generate a cinematic 9-scene sequence that progresses logically
from start to finish. Each frame should represent the next meaningful moment based on the
scene description.
The AI chooses all camera angles and framing automatically.
Ensure cinematic lighting, consistent color grading, realistic depth of field, and coherent
environmental evolution. No repeated shots.
SCENE INPUT: 【INPUT】
Frame 1:
Frame 2:
Frame 3:
Frame 4:
Frame 5:
Frame 6:
Frame 7:
Frame 8:
Frame 9:`;
  db.prepare('INSERT INTO settings (key, value) VALUES (?, ?)').run('storyboard_prompt', defaultStoryboardPrompt);
}

// Initialize carousel images
const carouselImagesSetting = db.prepare('SELECT value FROM settings WHERE key = ?').get('carousel_images') as { value: string } | undefined;
if (!carouselImagesSetting) {
  const defaultCarouselImages = JSON.stringify([
    'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?q=80&w=2564&auto=format&fit=crop',
    'https://images.unsplash.com/photo-1614850523459-c2f4c699c52e?q=80&w=2564&auto=format&fit=crop',
    'https://images.unsplash.com/photo-1618005192384-a83a8bd57fbe?q=80&w=2564&auto=format&fit=crop',
    'https://images.unsplash.com/photo-1614850715649-1d0106293bd1?q=80&w=2564&auto=format&fit=crop'
  ]);
  db.prepare('INSERT INTO settings (key, value) VALUES (?, ?)').run('carousel_images', defaultCarouselImages);
}

// Insert default presets if empty
const count = db.prepare('SELECT COUNT(*) as count FROM presets').get() as { count: number };
if (count.count === 0) {
  const insert = db.prepare('INSERT INTO presets (name, prompt_template) VALUES (?, ?)');
  insert.run('Cyberpunk', 'cyberpunk style, neon lights, futuristic, {prompt}');
  insert.run('Watercolor', 'watercolor painting, soft edges, pastel colors, {prompt}');
  insert.run('Photorealistic', 'photorealistic, 8k, highly detailed, {prompt}');
}

const app = express();
app.use(express.json({ limit: '50mb' }));

const PORT = 3000;

// Admin auth middleware
const requireAdmin = (req: express.Request, res: express.Response, next: express.NextFunction) => {
  const password = req.headers['x-admin-password'];
  if (password === '18190000') {
    next();
  } else {
    res.status(401).json({ error: 'Unauthorized' });
  }
};

// API Routes
app.get('/api/presets', (req, res) => {
  const presets = db.prepare('SELECT * FROM presets').all();
  res.json(presets);
});

app.post('/api/presets', requireAdmin, (req, res) => {
  const { name, prompt_template } = req.body;
  const info = db.prepare('INSERT INTO presets (name, prompt_template) VALUES (?, ?)').run(name, prompt_template);
  res.json({ id: info.lastInsertRowid, name, prompt_template });
});

app.delete('/api/presets/:id', requireAdmin, (req, res) => {
  db.prepare('DELETE FROM presets WHERE id = ?').run(req.params.id);
  res.json({ success: true });
});

app.get('/api/logs', requireAdmin, (req, res) => {
  const logs = db.prepare('SELECT * FROM logs ORDER BY timestamp DESC LIMIT 100').all();
  res.json(logs);
});

app.post('/api/logs', (req, res) => {
  const { prompt, model, status, error, image_data, attributes } = req.body;
  const info = db.prepare('INSERT INTO logs (prompt, model, status, error, image_data, attributes) VALUES (?, ?, ?, ?, ?, ?)').run(prompt, model, status, error, image_data, attributes ? JSON.stringify(attributes) : null);
  res.json({ id: info.lastInsertRowid });
});

app.get('/api/timer', (req, res) => {
  const row = db.prepare('SELECT value FROM settings WHERE key = ?').get('timer') as { value: string };
  res.json({ timer: parseInt(row.value, 10) });
});

app.post('/api/timer/decrement', (req, res) => {
  const row = db.prepare('SELECT value FROM settings WHERE key = ?').get('timer') as { value: string };
  let current = parseInt(row.value, 10);
  if (current > 0) {
    current -= 1;
    db.prepare('UPDATE settings SET value = ? WHERE key = ?').run(current.toString(), 'timer');
  }
  res.json({ timer: current });
});

app.post('/api/timer/reset', requireAdmin, (req, res) => {
  const bodyTimer = req.body?.timer;
  const newTimer = (bodyTimer !== undefined && bodyTimer !== null) ? bodyTimer.toString() : '100';
  db.prepare('UPDATE settings SET value = ? WHERE key = ?').run(newTimer, 'timer');
  res.json({ timer: parseInt(newTimer, 10) });
});

app.get('/api/settings/storyboard_prompt', (req, res) => {
  const row = db.prepare('SELECT value FROM settings WHERE key = ?').get('storyboard_prompt') as { value: string };
  res.json({ prompt: row.value });
});

app.post('/api/settings/storyboard_prompt', requireAdmin, (req, res) => {
  const { prompt } = req.body;
  db.prepare('UPDATE settings SET value = ? WHERE key = ?').run(prompt, 'storyboard_prompt');
  res.json({ success: true });
});

app.get('/api/settings/carousel_images', (req, res) => {
  const row = db.prepare('SELECT value FROM settings WHERE key = ?').get('carousel_images') as { value: string };
  res.json({ images: JSON.parse(row.value) });
});

app.post('/api/settings/carousel_images', requireAdmin, (req, res) => {
  const { images } = req.body;
  db.prepare('UPDATE settings SET value = ? WHERE key = ?').run(JSON.stringify(images), 'carousel_images');
  res.json({ success: true });
});

async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static('dist'));
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
