const fetch = require('node-fetch');

async function test() {
  const res = await fetch('http://localhost:3000/api/timer/reset', {
    method: 'POST',
    headers: {
      'x-admin-password': '18190000',
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({ timer: 2 })
  });
  const data = await res.json();
  console.log(data);
}

test();
