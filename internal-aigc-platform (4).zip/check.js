async function check() {
  try {
    const res = await fetch('http://localhost:3000');
    console.log(res.status);
    const text = await res.text();
    console.log(text.substring(0, 200));
  } catch(e) {
    console.error(e);
  }
}
check();
